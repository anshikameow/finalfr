// ─────────────────────────────────────────────────────────────
// Groq AI client
// Groq is free, fast, and works globally including India.
// Get your key at: https://console.groq.com/keys
// ─────────────────────────────────────────────────────────────

const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const MODEL = "llama-3.3-70b-versatile"; // Free, fast, excellent reasoning

export const getGroqKey = (): string => {
  const viteEnvKey = import.meta.env.VITE_GROQ_API_KEY;
  const localStorageKey = typeof window !== 'undefined'
    ? localStorage.getItem('REMINIQ_GROQ_API_KEY')
    : null;

  const cleanKey = (key: any): string | null => {
    if (!key || key === "undefined" || key === "null" || key === "YOUR_GROQ_API_KEY") return null;
    return String(key).trim();
  };

  const apiKey = cleanKey(viteEnvKey) || cleanKey(localStorageKey);

  if (!apiKey) {
    throw new Error(
      "Groq API Key is missing.\n\n" +
      "On Vercel: add VITE_GROQ_API_KEY to your project's Environment Variables.\n" +
      "Locally: add VITE_GROQ_API_KEY=\"your-key\" to a .env file.\n" +
      "Or paste it via the gear icon in the app.\n\n" +
      "Get a free key at: https://console.groq.com/keys"
    );
  }

  return apiKey;
};

// Core fetch wrapper — uses Groq's OpenAI-compatible API
async function groqChat(
  apiKey: string,
  systemPrompt: string,
  userPrompt: string,
  jsonMode = true
): Promise<string> {
  const response = await fetch(GROQ_API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      ...(jsonMode ? { response_format: { type: "json_object" } } : {}),
      temperature: 0.3,
      max_tokens: 4096,
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    const msg = (err as any)?.error?.message || response.statusText;
    const status = response.status;

    if (status === 401) {
      throw new Error("Invalid Groq API key. Please check your key at console.groq.com/keys");
    }
    if (status === 429) {
      throw new Error("Groq rate limit hit. Please wait a moment and try again. (Free tier: 30 req/min)");
    }
    throw new Error(`Groq API error (${status}): ${msg}`);
  }

  const data = await response.json();
  const text = data?.choices?.[0]?.message?.content;
  if (!text) throw new Error("Empty response from Groq.");
  return text;
}

function parseJsonSafe(text: string): any {
  try {
    return JSON.parse(text);
  } catch {
    const cleaned = text.replace(/```json|```/g, '').trim();
    return JSON.parse(cleaned);
  }
}

// ─────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────

export interface Memory {
  id: string;
  type: 'photo' | 'voice' | 'text' | 'music';
  title: string;
  desc: string;
  mood: string;
  location?: string;
  date: string;
  photoUrl?: string;
  audioUrl?: string;
  musicUrl?: string;
  transcript?: string;
  emotion?: string;
  music?: {
    song: string;
    artist: string;
    albumArt?: string;
  };
}

export interface DayReaction {
  date: string;
  emoji: string;
}

export interface Album {
  id: string;
  title: string;
  memoryIds: string[];
  journalText?: string;
  linkedMemoryIds?: string[];
  voiceNoteUrl?: string;
}

// ─────────────────────────────────────────────────────────────
// Visual fingerprint helper
// Extracts rich signals from a memory so the model reasons better
// ─────────────────────────────────────────────────────────────

function visualFingerprint(m: Memory): string {
  const parts: string[] = [];

  if (m.type === 'photo') parts.push('photo/visual');
  if (m.type === 'voice') parts.push('audio/voice');
  if (m.type === 'music') parts.push(`music: ${m.music?.song || ''} by ${m.music?.artist || ''}`);
  if (m.type === 'text') parts.push('written note');

  const moodMap: Record<string, string> = {
    happy: 'joyful, bright, warm',
    sad: 'melancholic, quiet, blue',
    nostalgic: 'wistful, bittersweet, longing',
    excited: 'energetic, vibrant, electric',
    calm: 'peaceful, serene, still',
    anxious: 'tense, restless, unsettled',
    romantic: 'intimate, tender, loving',
    adventurous: 'wild, free, bold',
    cozy: 'warm, soft, safe',
    melancholy: 'blue, reflective, tender-sad',
  };
  const moodExpanded = moodMap[m.mood?.toLowerCase()] || m.mood || 'neutral';
  parts.push(`mood: ${moodExpanded}`);

  const desc = (m.desc + ' ' + m.title).toLowerCase();
  if (/morning|sunrise|dawn|breakfast/.test(desc)) parts.push('time-of-day: morning');
  else if (/afternoon|lunch|midday/.test(desc)) parts.push('time-of-day: afternoon');
  else if (/evening|sunset|dusk|dinner/.test(desc)) parts.push('time-of-day: evening');
  else if (/night|midnight|late|stars/.test(desc)) parts.push('time-of-day: night');

  if (/rain|storm|wet|grey|gray|overcast/.test(desc)) parts.push('weather: rainy/grey');
  else if (/snow|winter|cold|frost/.test(desc)) parts.push('weather: winter/cold');
  else if (/sun|sunny|bright|golden|warm/.test(desc)) parts.push('weather: sunny/warm');
  else if (/fog|mist|haze/.test(desc)) parts.push('weather: misty');

  if (/mountain|hill|trek|hike|forest|nature|beach|ocean|sea|river|lake/.test(desc))
    parts.push('setting: outdoors/nature');
  else if (/café|cafe|restaurant|bar|pub|market|mall|shop|street|city|road/.test(desc))
    parts.push('setting: urban/social');
  else if (/home|room|bed|couch|kitchen|balcony|terrace/.test(desc))
    parts.push('setting: home/intimate');

  return parts.join(' | ');
}

// ─────────────────────────────────────────────────────────────
// sortMemoriesIntoAlbums  — two-pass: analyse → group
// ─────────────────────────────────────────────────────────────

export async function sortMemoriesIntoAlbums(memories: Memory[]): Promise<Album[]> {
  if (memories.length === 0) return [];

  const apiKey = getGroqKey();

  // ── PASS 1: semantically tag each memory ─────────────────────
  const memoryRows = memories.map(m => ({
    id: m.id,
    title: m.title,
    desc: m.desc,
    location: m.location || 'Unknown',
    date: m.date,
    mood: m.mood,
    type: m.type,
    visualFingerprint: visualFingerprint(m),
    hasPhoto: !!m.photoUrl,
  }));

  const pass1System = `You are an expert photo-memory analyst. You receive raw memory data and extract rich semantic tags.
Always respond with valid JSON only — no markdown, no extra text.`;

  const pass1User = `Analyse each memory and extract semantic tags to help group them into meaningful albums.

For EVERY memory return:
- "id": unchanged
- "visualTone": one of [bright, warm, golden, cool, moody, dark, misty, vibrant, muted, dramatic]
- "settingType": one of [outdoors-nature, outdoors-urban, indoors-home, indoors-social, travel, unknown]
- "energyLevel": one of [high, medium, low, quiet]
- "timeOfDay": one of [morning, afternoon, evening, night, unknown]
- "season": infer from date + description — one of [spring, summer, monsoon, autumn, winter, unknown]
- "primaryEmotion": single word (joy, nostalgia, peace, excitement, romance, melancholy, wonder, etc.)
- "locationCluster": short normalised place label — group nearby/similar places under the same label (e.g. "Mumbai", "Goa beach", "home", "mountains")
- "suggestedTheme": 2-4 word poetic phrase capturing this memory's essence

Memories:
${JSON.stringify(memoryRows, null, 2)}

Return exactly:
{ "tagged": [ { "id": "...", "visualTone": "...", "settingType": "...", "energyLevel": "...", "timeOfDay": "...", "season": "...", "primaryEmotion": "...", "locationCluster": "...", "suggestedTheme": "..." } ] }`;

  let taggedMemories: any[] = [];
  try {
    const pass1Text = await groqChat(apiKey, pass1System, pass1User, true);
    const pass1 = parseJsonSafe(pass1Text);
    taggedMemories = Array.isArray(pass1) ? pass1 : (pass1.tagged ?? []);
  } catch (e) {
    console.warn("Pass 1 tagging failed, proceeding with pass 2 only:", e);
  }

  // Merge tags back
  const tagMap: Record<string, any> = {};
  for (const t of taggedMemories) tagMap[t.id] = t;

  const enrichedSummary = memories.map(m => {
    const tags = tagMap[m.id] || {};
    return [
      `ID: ${m.id}`,
      `Title: "${m.title}"`,
      `Desc: "${m.desc}"`,
      `Location: ${m.location || 'Unknown'} → cluster: ${tags.locationCluster || 'Unknown'}`,
      `Date: ${m.date} | Season: ${tags.season || '?'} | TimeOfDay: ${tags.timeOfDay || '?'}`,
      `VisualTone: ${tags.visualTone || '?'} | Setting: ${tags.settingType || '?'} | Energy: ${tags.energyLevel || '?'}`,
      `Emotion: ${tags.primaryEmotion || m.mood} | Theme: ${tags.suggestedTheme || m.mood}`,
      `Type: ${m.type} | HasPhoto: ${!!m.photoUrl}`,
    ].join(' | ');
  }).join('\n\n');

  // ── PASS 2: group enriched memories into albums ───────────────
  const pass2System = `You are a thoughtful memory curator creating a personal photo album.
You have rich semantic analysis for each memory. Use ALL signals — visual tone, setting, emotion, location cluster, time of day, season — to create albums that feel genuinely cohesive, as if a human hand-picked them.
Always respond with valid JSON only — no markdown, no extra text.`;

  const pass2User = `Group these analysed memories into albums.

GROUPING PRIORITY (apply strictly in this order):
1. VISUAL & EMOTIONAL COHERENCE — same visual tone + compatible emotion = strongest bond. A warm-golden joyful photo and a cool-moody melancholy photo should NEVER share an album even if taken at the same location.
2. LOCATION CLUSTER — memories from the same place/trip belong together IF their mood is also compatible.
3. TIME CONTEXT — same time-of-day or season strengthens a grouping but never overrides a visual/emotional mismatch.

RULES:
- Every memory must appear in exactly ONE album — no memory left out, no duplicates.
- Aim for 2–5 albums. Never create a 1-memory album unless ≤2 memories total.
- Album titles: 3–5 words, poetic, evocative. NEVER generic titles like "Happy Memories" or "Misc Photos".
- Group by VIBE over date — two rainy-evening photos from different months belong together more than a sunny and a rainy photo from the same day.
- For ambiguous memories, match by VISUAL TONE first.

Memories (with full semantic analysis):
${enrichedSummary}

Return JSON:
{
  "albums": [
    {
      "title": "Poetic Album Title",
      "rationale": "one sentence: why these memories belong together visually and emotionally",
      "memoryIds": ["id1", "id2"]
    }
  ]
}`;

  const pass2Text = await groqChat(apiKey, pass2System, pass2User, true);
  const pass2 = parseJsonSafe(pass2Text);
  const albumsData: any[] = Array.isArray(pass2) ? pass2 : (pass2.albums ?? []);

  if (!albumsData.length) {
    throw new Error("Could not group memories into albums. Try adding more descriptive titles or moods.");
  }

  // Safety net: ensure every memory is assigned
  const assignedIds = new Set(albumsData.flatMap((a: any) => a.memoryIds || []));
  const unassigned = memories.filter(m => !assignedIds.has(m.id));
  if (unassigned.length > 0 && albumsData.length > 0) {
    const largest = albumsData.reduce((a: any, b: any) =>
      (a.memoryIds?.length || 0) >= (b.memoryIds?.length || 0) ? a : b
    );
    largest.memoryIds.push(...unassigned.map((m: Memory) => m.id));
  }

  return albumsData.map((a: any) => ({
    id: Math.random().toString(36).substr(2, 9),
    title: a.title || "Untitled Album",
    memoryIds: a.memoryIds || [],
    journalText: a.rationale || undefined,
  }));
}

// ─────────────────────────────────────────────────────────────
// searchMemories
// ─────────────────────────────────────────────────────────────

export async function searchMemories(query: string, memories: Memory[]) {
  if (memories.length === 0) return null;

  const apiKey = getGroqKey();

  const memoryContext = memories.map(m => ({
    id: m.id,
    title: m.title,
    desc: m.desc,
    type: m.type,
    mood: m.mood,
    location: m.location,
  }));

  const systemPrompt = `You are the librarian of "Reminiq", a personal memory journal app.
Always respond with valid JSON only — no markdown, no extra text.`;

  const userPrompt = `A user is searching for a memory with the query: "${query}".

Here are the memories in their vault:
${JSON.stringify(memoryContext, null, 2)}

Find the most relevant memory and return a JSON object:
{
  "intro": "A poetic, nostalgic one-sentence introduction to the memory you found.",
  "memoryId": "the-matching-id"
}

If nothing matches well, return:
{
  "intro": "I couldn't find that specific moment, but your vault is still full of stories.",
  "memoryId": null
}`;

  try {
    const text = await groqChat(apiKey, systemPrompt, userPrompt, true);
    const cleaned = text.replace(/```json|```/g, '').trim();
    return JSON.parse(cleaned);
  } catch (error: any) {
    console.error("Groq search error:", error);
    throw error;
  }
}

// ─────────────────────────────────────────────────────────────
// chatWithMemories  (used by SmartChat)
// ─────────────────────────────────────────────────────────────

export async function chatWithMemories(
  userMessage: string,
  memories: Memory[]
): Promise<{ action: 'chat' | 'create_album'; message: string; album?: Omit<Album, 'id'> }> {
  const apiKey = getGroqKey();

  const memorySummary = memories.map(m => ({
    id: m.id,
    title: m.title,
    desc: m.desc,
    mood: m.mood,
    date: m.date,
  }));

  const systemPrompt = `You are a helpful AI assistant for a personal memory journal app called Reminiq.
Always respond with valid JSON only — no markdown, no extra text.`;

  const userPrompt = `Current Memories: ${JSON.stringify(memorySummary)}

User Request: "${userMessage}"

If the user wants to sort, group, or create an album, return:
{
  "action": "create_album",
  "album": {
    "title": "Album Title",
    "memoryIds": ["id1", "id2"],
    "journalText": "A short poetic summary of these memories."
  },
  "message": "A friendly message explaining what you did."
}

If just chatting, return:
{
  "action": "chat",
  "message": "Your response message here."
}`;

  const text = await groqChat(apiKey, systemPrompt, userPrompt, true);
  const cleaned = text.replace(/```json|```/g, '').trim();
  return JSON.parse(cleaned);
}
